<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Items CRUD</h2>
            </div>
            <div class="pull-right">

                    <?php if(!empty($id)): ?>

                <a class="btn btn-success" href="<?php echo e(route('menu.create',$id)); ?>"> Create New Item</a>
                <?php endif; ?>
                <?php if(empty($id)): ?>
                        <a class="btn btn-success" href="<?php echo e(route('menu.create')); ?>"> Create New Item</a>
                  <?php endif; ?>
            </div>
        </div>
    </div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Menu_Title</th>
            <th>Status</th>
            <th width="280px">Action</th>
        </tr>
        <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $menu): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr>
                <td><?php echo e(++$i); ?></td>
                <td><?php echo e($menu->menuTitle); ?></td>
                <td><?php echo e($menu->status); ?></td>
                <td>
                    <a class="btn btn-info" href="<?php echo e(route('menu.changeStatus',$menu->id)); ?>">Change Status</a>
                    <a class="btn btn-info" href="<?php echo e(route('menu.index',$menu->id)); ?>">View SubCategory</a>
                    <a class="btn btn-info" href="<?php echo e(route('menu.create',$menu->id)); ?>">Add SubCategory</a>
                    <a class="btn btn-primary" href="<?php echo e(route('menu.edit',$menu->id)); ?>">Edit</a>
                <a onclick="return confirm('Are you sure you want to delete this menu?');" href="<?php echo e(route('menu.destroy',$menu->id)); ?>"><button class="btn btn-primary">Delete</button></a>


                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </table>

    <?php echo $menus->render(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>