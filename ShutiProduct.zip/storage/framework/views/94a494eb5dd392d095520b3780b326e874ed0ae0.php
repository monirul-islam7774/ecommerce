<?php

$mainmenus = \App\Menu::where('parentId', '=', NULL)->where('status','=','Enabled')->get();
$menus = \App\Menu::where('parentId', '!=', NULL)->where('status','=','Enabled')->get();
$count = (int)sizeof($mainmenus);
if($count==0){
    $col=1;
}
else
 $col = floor(12 / $count);
?>


<div class="header">
    <div class="container">

        <div  class="w3l_logo">
            <h1 ><a  href="<?php echo e(url('/')); ?>">SHUTI<span>Tradition of Bangladesh</span></a></h1>
        </div>
        <div class="search">
            <input class="search_box" type="checkbox" id="search_box">
            <label class="icon-search" for="search_box"><span class="glyphicon glyphicon-search"
                                                              aria-hidden="true"></span></label>
            <div class="search_form">
                <form action="#" method="post">
                    <input type="text" name="Search" placeholder="Search...">
                    <input type="submit" value="Send">
                </form>
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
<div class="navigation">
    <div class="container">
        <nav class="navbar navbar-default">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header nav_2">
                <button type="button" class="navbar-toggle collapsed navbar-toggle1" data-toggle="collapse"
                        data-target="#bs-megadropdown-tabs">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
            </div>
            <div class="collapse navbar-collapse" id="bs-megadropdown-tabs">
                <?php if( Request::is('/') || Request::is('photo_gallery') ||Request::is('contact_us') ||Request::is('about_us')): ?>
                    <ul class="nav navbar-nav">
                        <li >
                            <a  <?php echo (Request::is('/') ? 'class="act"' : ''); ?> href="<?php echo e(url('/')); ?>" class="">Home</a>
                        </li>
                        <!-- Mega Menu -->
                        <li class="dropdown" >
                            <a   href="#" class="dropdown-toggle" data-toggle="dropdown">Products <b class="caret"></b></a>
                            <ul class="dropdown-menu multi-column columns-3">
                                <div class="row">
                                    <?php $__currentLoopData = $mainmenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <div class="col-sm-<?php echo e($col); ?>">
                                            <ul class="multi-column-dropdown">
                                                <h6><a href="<?php echo e(url('product/'.$menu->menuTitle.'&_id='.$menu->id)); ?>"><?php echo e($menu->menuTitle); ?></a></h6>

                                                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                    <?php if($submenu->parentId==$menu->id): ?>
                                                        <li><a href="<?php echo e(url('product/'.$submenu->menuTitle.'&_id='.$submenu->id)); ?>"><?php echo e($submenu->menuTitle); ?></a></li>
                                                        <ul style="margin-left: 3%;" class="multi-column-dropdown">
                                                            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenus): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                <?php if($submenus->parentId==$submenu->id): ?>
                                                                    <li> <a href="<?php echo e(url('product/'.$submenus->menuTitle.'&_id='.$submenus->id)); ?>"><i class="fa fa-long-arrow-right" aria-hidden="true"></i> <?php echo e($submenus->menuTitle); ?></a></li>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                                        </ul>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                            </ul>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    <div class="clearfix"></div>
                                </div>
                            </ul>
                        </li>
                        <li >
                            <a <?php echo (Request::is('photo_gallery') ? 'class="act"' : ''); ?> href="<?php echo e(url('photo_gallery')); ?>">Gallery</a>
                        </li>
                        <li><a <?php echo (Request::is('about_us') ? 'class="act"' : ''); ?> href="<?php echo e(url('about_us')); ?>">About Us</a></li>
                        <li><a  <?php echo (Request::is('contact_us') ? 'class="act"' : ''); ?> href="<?php echo e(url('contact_us')); ?>">Contact Us</a></li>
                    </ul>
                    <?php else: ?>
                    <ul class="nav navbar-nav">
                        <li >
                            <a  href="<?php echo e(url('/')); ?>" class="">Home</a>
                        </li>
                        <!-- Mega Menu -->
                        <li class="dropdown" >
                            <a class="act"   href="#" class="dropdown-toggle" data-toggle="dropdown">Products <b class="caret"></b></a>
                            <ul class="dropdown-menu multi-column columns-3">
                                <div class="row">
                                    <?php $__currentLoopData = $mainmenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                                        <div class="col-sm-<?php echo e($col); ?>">
                                            <ul class="multi-column-dropdown">
                                                <h6><a href="<?php echo e(url('product/'.$menu->menuTitle.'&_id='.$menu->id)); ?>"><?php echo e($menu->menuTitle); ?></a></h6>

                                                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                    <?php if($submenu->parentId==$menu->id): ?>
                                                        <li><a href="<?php echo e(url('product/'.$submenu->menuTitle.'&_id='.$submenu->id)); ?>"><?php echo e($submenu->menuTitle); ?></a></li>
                                                        <ul style="margin-left: 3%;" class="multi-column-dropdown">
                                                            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenus): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                                <?php if($submenus->parentId==$submenu->id): ?>
                                                                    <li> <a href="<?php echo e(url('product/'.$submenus->menuTitle.'&_id='.$submenus->id)); ?>"><i class="fa fa-long-arrow-right" aria-hidden="true"></i> <?php echo e($submenus->menuTitle); ?></a></li>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                                        </ul>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                            </ul>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    <div class="clearfix"></div>
                                </div>
                            </ul>
                        </li>
                        <li >
                            <a  href="<?php echo e(url('photo_gallery')); ?>">Gallery</a>
                        </li>
                        <li><a href="<?php echo e(url('about_us')); ?>">About Us</a></li>
                        <li><a  href="<?php echo e(url('contact_us')); ?>">Contact Us</a></li>
                    </ul>
                    <?php endif; ?>

            </div>
        </nav>
    </div>
</div>
