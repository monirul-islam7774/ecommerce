<?php

$mainmenus = \App\Menu::where('parentId', '=', NULL)->where('status','=','Enabled')->get();
$menus = \App\Menu::where('parentId', '!=', NULL)->where('status','=','Enabled')->get();
$single=\App\Menu::where([['parentId', '=', NULL],
                          ['childCsv','=',NULL],
                          ['status','=','Enabled'],
                           ])->get();

?>

<div class="col-md-4 w3ls_dresses_grid_left">
    <div class="w3ls_dresses_grid_left_grid">
        <h3>Categories</h3>
        <div class="w3ls_dresses_grid_left_grid_sub">
            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">

                <?php $__currentLoopData = $mainmenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <div class="panel panel-default">
                    <div class="panel-heading" role="tab" id="headingOne">
                        <h4 class="panel-title asd">
                            <a class="pa_italic collapsed"  href="<?php echo e(url('product/'.$menu->menuTitle.'&_id='.$menu->id)); ?>" aria-expanded="true">
                                <span class="glyphicon glyphicon-minus" aria-hidden="true"></span><i class="glyphicon glyphicon-minus" aria-hidden="true"></i><?php echo e(strtoupper($menu->menuTitle)); ?>

                            </a>
                        </h4>
                    </div>
                    <div id="collapseOne"  role="tabpanel" aria-labelledby="headingOne">
                        <div class="panel-body panel_text">
                            <ul>
                                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <?php if($item->parentId==$menu->id): ?>
                                     <li><a href="<?php echo e(url('product/'.$item->menuTitle.'&_id='.$item->id)); ?>"><?php echo e(strtoupper($item->menuTitle)); ?></a></li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </ul>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </div>
            <ul class="panel_bottom">
                <?php $__currentLoopData = $single; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <li><a href="products.html"><?php echo e(strtoupper($item->menuTitle)); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
        </div>
    </div>

</div>