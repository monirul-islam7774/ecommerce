<?php $__env->startSection('content'); ?>
    <!-- banner -->
    <div style="margin: 0;padding: 0;" class="w3agile_special_deals_grids">
        <div style="margin: 0;padding: 0;"  class="col-md-12 w3agile_special_deals_grid_left">
            <div class="w3agile_special_deals_grid_left_grid">

                <?php if($banner): ?>
                    <img
                            src="<?php echo e(asset('gallery-images/'.$banner->image)); ?>" alt=" "
                            class="img-responsive"/>
                <?php else: ?>
                    <img
                            src="<?php echo e(asset('gallery-images/default.jpg')); ?>" alt=" "
                            class="img-responsive"/>
                <?php endif; ?>


            </div>
        </div>
    </div>
    <!-- //banner -->

    <!-- breadcrumbs -->
    <div class="breadcrumb_dress">
        <div class="container">
            <ul>
                <li><a href="index.html"><span class="glyphicon glyphicon-home" aria-hidden="true"></span> Home</a>
                    <i>/</i></li>
                <li>Product</li>
            </ul>
        </div>
    </div>
    <!-- //breadcrumbs -->

    <!-- dresses -->
    <div style="padding:5em 0;" class="dresses">
        <div class="container">
            <div class="w3ls_dresses_grids">
                <?php echo $__env->make('layouts._left_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="col-md-8 w3ls_dresses_grid_right">
                    
                    <div class="w3ls_dresses_grid_right_grid3">

                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <div class="col-md-4 agileinfo_new_products_grid agileinfo_new_products_grid_dresses">
                                <div class="agile_ecommerce_tab_left dresses_grid">
                                    <div class="hs-wrapper hs-wrapper2">

                                       <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <?php if($product->productCode==$photo->productCode): ?>
                                                <img src="<?php echo e(asset('product-images/'.$photo->image)); ?>" alt=" "
                                                     class="img-responsive"/>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                           <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                               <?php if($product->productCode==$photo->productCode): ?>
                                                   <img src="<?php echo e(asset('product-images/'.$photo->image)); ?>" alt=" "
                                                        class="img-responsive"/>
                                               <?php endif; ?>
                                           <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                        <div class="w3_hs_bottom w3_hs_bottom_sub1">
                                            <ul>
                                                <li>
                                                    <a href="<?php echo e(url('product_details','productCode-'.$product->productCode)); ?>"><span
                                                                class="glyphicon glyphicon-eye-open"
                                                                aria-hidden="true"></span></a>
                                                </li>
                                            </ul>
                                        </div>
                                    </div>
                                    <h5><a href="<?php echo e(url('product_details','productCode-'.$product->productCode)); ?>"><?php echo e($product->name); ?></a></h5>
                                    <div class="simpleCart_shelfItem">
                                        <?php if($product->status=='Offer'): ?>
                                            <p><i class="item_price"><?php echo e($product->offerPrice); ?>

                                                    </i><span><?php echo e($product->price); ?></span></p>
                                        <?php else: ?>
                                            <p><i class="item_price">BDT <?php echo e($product->price); ?> Tk</i></p>
                                        <?php endif; ?>
                                        <p><a class="item_add" href="<?php echo e(url('product_details','productCode-'.$product->productCode)); ?>">View
                                                Details</a></p>
                                    </div>
                                    <div class="dresses_grid_pos">
                                        <h6>New</h6>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        <div class="clearfix"></div>
                    </div>
                </div>


            </div>
            <div class="pull-right">
                <?php echo $products->links(); ?>

            </div>
        </div>
    </div>

    <?php if(sizeof($related_products)>0): ?>
    <div style="padding:2% 0;" class="new-products">
        <div class="container">
            <h3><a href="">Related Product</a></h3>
            <ul id="flexiselDemo2">
                <?php $__currentLoopData = $related_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li>
                        <div class="w3l_related_products_grid">
                            <div class="agile_ecommerce_tab_left dresses_grid">
                                <div class="hs-wrapper hs-wrapper3">
                                    <?php $__currentLoopData = $related_photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <?php if($item->productCode==$photo->productCode): ?>
                                            <img src="<?php echo e(asset('product-images/'.$photo->image)); ?>" alt=" "
                                                 class="img-responsive">

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                        <?php $__currentLoopData = $related_photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <?php if($item->productCode==$photo->productCode): ?>
                                                <img src="<?php echo e(asset('product-images/'.$photo->image)); ?>" alt=" "
                                                     class="img-responsive">

                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                    <div class="w3_hs_bottom">
                                        <div class="flex_ecommerce">
                                            <a href="<?php echo e(url('product_details','productCode-'.$item->productCode)); ?>"><span
                                                        class="glyphicon glyphicon-eye-open" aria-hidden="true"></span></a>
                                        </div>
                                    </div>
                                </div>
                                <h5><a href="<?php echo e(url('product_details','productCode-'.$item->productCode)); ?>"><?php echo e($item->name); ?></a></h5>
                                <div class="simpleCart_shelfItem">
                                    <?php if($item->offerPercentage==''): ?>
                                        <p class="flexisel_ecommerce_cart"><i class="item_price">BDT <?php echo e($item->price); ?>

                                                Tk</i></p>
                                    <?php else: ?>
                                        <p class="flexisel_ecommerce_cart"> <i
                                                    class="item_price"><?php echo e($item->offerPrice); ?></i> <span><?php echo e($item->price); ?></span></p>

                                    <?php endif; ?>

                                    <p><a class="item_add" href="<?php echo e(url('product_details','productCode-'.$item->productCode)); ?>">View Details</a></p>
                                </div>
                            </div>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
            <script type="text/javascript">

            </script>
        </div>
    </div>
    <!-- //dresses -->
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_script'); ?>


    <script>

        $(window).load(function () {
            $("#flexiselDemo2").flexisel({
                visibleItems: 4,
                animationSpeed: 800,
                autoPlay: true,
                autoPlaySpeed: 3000,
                pauseOnHover: true,
                enableResponsiveBreakpoints: true,
                responsiveBreakpoints: {
                    portrait: {
                        changePoint: 480,
                        visibleItems: 1
                    },
                    landscape: {
                        changePoint: 640,
                        visibleItems: 2
                    },
                    tablet: {
                        changePoint: 768,
                        visibleItems: 3
                    }
                }
            });

        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>