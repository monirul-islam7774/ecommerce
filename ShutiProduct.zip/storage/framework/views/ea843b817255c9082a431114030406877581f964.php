<link href="https://fonts.googleapis.com/css?family=Lato:100" rel="stylesheet" type="text/css">

<style>

    .title {
        font-size: 30px;
        margin: 20% 0;
        text-align: center;
    }
</style>


<?php $__env->startSection('content'); ?>
    <!-- banner -->
    <div class="banner1" id="home1">
        <div class="container">
            <h2>trendy fashion dresses<span>up to</span> 30% <i>Discount</i></h2>
        </div>
    </div>
    <!-- //banner -->

    <!-- breadcrumbs -->
    <div class="breadcrumb_dress">
        <div class="container">
            <ul>
                <li><a href="index.html"><span class="glyphicon glyphicon-home" aria-hidden="true"></span> Home</a> <i>/</i></li>
                <li>Dresses</li>
            </ul>
        </div>
    </div>
    <!-- //breadcrumbs -->

    <!-- dresses -->
    <div style="padding:5em 0;" class="dresses">
        <div class="container">
            <div class="w3ls_dresses_grids">
                <?php echo $__env->make('layouts._left_menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="col-md-8 w3ls_dresses_grid_right">

                    <div class="w3ls_dresses_grid_right_grid2">
                        <div class="w3ls_dresses_grid_right_grid2_left">
                            <h3>Showing Results: 0-1</h3>
                        </div>
                        <div class="w3ls_dresses_grid_right_grid2_right">
                            <select name="select_item" class="select_item">
                                <option selected="selected">Default sorting</option>
                                <option>Sort by popularity</option>
                                <option>Sort by average rating</option>
                                <option>Sort by newness</option>
                                <option>Sort by price: low to high</option>
                                <option>Sort by price: high to low</option>
                            </select>
                        </div>
                        <div class="clearfix"> </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="content">
            <div class="title">Be right back.</div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_script'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>