<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Product CRUD</h2>
            </div>
            <div class="pull-right">

                <a class="btn btn-success" href="<?php echo e(route('productPhoto.create')); ?>"> Create New Product</a>

            </div>
        </div>
    </div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Product Code</th>
            <th>Product Image</th>
            <th width="280px">Action</th>
        </tr>
        <?php $__currentLoopData = $productPhotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr>
                <td><?php echo e(++$i); ?></td>
                <td><?php echo e($product->productCode); ?></td>
                <td><img src="<?php echo e(asset('images/'.$product->image)); ?>" height="30px" width="30px" /></td>

                <td>

                    <a class="btn btn-primary" href="<?php echo e(route('product.productPhotoEdit',$product->id)); ?>">Edit</a>
                    <a onclick="return confirm('Are you sure you want to delete this Product?');" href="<?php echo e(route('product.productPhotoDestroy',$product->id)); ?>"><button class="btn btn-primary">Delete</button></a>


                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </table>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>