<?php $__env->startSection('content'); ?>

    <!-- banner -->
    <!--banner-starts-->
    <div class="bnr">
        <div id="top" class="callbacks_container">
            <ul class="rslides" id="slider4">
                <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pic): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li>
                        <img src="<?php echo e(asset('gallery-images/'.$pic->image)); ?>" alt=""/>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
        </div>
        <div class="clearfix"></div>
    </div>
    <!--banner-ends-->
    <!--Slider-Starts-Here-->

    <?php
    $mainmenus = \App\Menu::where('parentId', '=', NULL)->where('status', '=', 'Enabled')->get();
    $count = (int)sizeof($mainmenus);
    ?>
    <!-- special-deals -->
    <?php if($count>1): ?>
    <div class="special-deals">

        <div class="w3agile_special_deals_grids">
            <div class="col-md-6 w3agile_special_deals_grid_left">
                <div class="w3agile_special_deals_grid_left_grid">
                    <a href="<?php echo e(url('product/'.$mainmenus[0]->menuTitle.'&_id='.$mainmenus[0]->id)); ?>">
                        <?php if($banner1): ?>
                            <img
                                src="<?php echo e(asset('gallery-images/'.$banner1->image)); ?>" alt=" "
                                class="img-responsive"/>
                            <?php else: ?>
                            <img
                                    src="<?php echo e(asset('frontend/images/default1.jpg')); ?>" alt=" "
                                    class="img-responsive"/>
                            <?php endif; ?>
                    </a>

                    <div class="w3agile_special_deals_grid_left_grid_pos">
                        <h4><?php echo e($mainmenus[0]->menuTitle); ?> <span>Collection</span></h4>
                    </div>
                </div>
            </div>
            <div class="col-md-6 w3agile_special_deals_grid_left">
                <div class="w3agile_special_deals_grid_left_grid">
                    <a href="<?php echo e(url('product/'.$mainmenus[1]->menuTitle.'&_id='.$mainmenus[1]->id)); ?>">
                        <?php if($banner2): ?>
                            <img
                                    src="<?php echo e(asset('gallery-images/'.$banner2->image)); ?>" alt=" "
                                    class="img-responsive"/>
                        <?php else: ?>
                            <img
                                    src="<?php echo e(asset('frontend/images/default1.jpg')); ?>" alt=" "
                                    class="img-responsive"/>
                        <?php endif; ?>
                    </a>

                    <div class="w3agile_special_deals_grid_left_grid_pos">
                        <h4><?php echo e($mainmenus[1]->menuTitle); ?> <span>Collection</span></h4>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
    <?php endif; ?>
    <!-- //special-deals -->
    <!-- new-products -->
    <div style="padding:2% 0;" class="new-products">
        <div class="container">
            <h3><a href="">New Products</a></h3>
            <ul id="flexiselDemo2">
                <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li>
                        <div class="w3l_related_products_grid">
                            <div class="agile_ecommerce_tab_left dresses_grid">
                                <div class="hs-wrapper hs-wrapper3">
                                    <?php $__currentLoopData = $new_photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <?php if($item->productCode==$photo->productCode): ?>
                                            <img src="<?php echo e(asset('product-images/'.$photo->image)); ?>" alt=" "
                                                 class="img-responsive">

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                        <?php $__currentLoopData = $new_photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <?php if($item->productCode==$photo->productCode): ?>
                                                <img src="<?php echo e(asset('product-images/'.$photo->image)); ?>" alt=" "
                                                     class="img-responsive">

                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                    <div class="w3_hs_bottom">
                                        <div class="flex_ecommerce">
                                            <a href="<?php echo e(url('product_details','productCode-'.$item->productCode)); ?>"><span
                                                        class="glyphicon glyphicon-eye-open" aria-hidden="true"></span></a>
                                        </div>
                                    </div>
                                </div>
                                <h5>
                                    <a href="<?php echo e(url('product_details','productCode-'.$item->productCode)); ?>"><?php echo e($item->name); ?></a>
                                </h5>
                                <div class="simpleCart_shelfItem">
                                    <?php if($item->offerPercentage==''): ?>
                                        <p class="flexisel_ecommerce_cart"><i class="item_price">BDT <?php echo e($item->price); ?>

                                                Tk</i></p>
                                    <?php else: ?>
                                        <p class="flexisel_ecommerce_cart"><i
                                                    class="item_price"><?php echo e($item->offerPrice); ?></i>
                                            <span><?php echo e($item->price); ?></span></p>

                                    <?php endif; ?>

                                    <p><a class="item_add"
                                          href="<?php echo e(url('product_details','productCode-'.$item->productCode)); ?>">View
                                            Details</a></p>
                                </div>
                            </div>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
            <script type="text/javascript">

            </script>
        </div>
    </div>
    <!-- //new-products -->
    <div style="padding:2% 0;" class="w3l_related_products">
        <div class="container">
            <h3><a href="">offer Products</a></h3>
            <ul id="flexiselDemo3">
                <?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                    <li>
                        <div class="w3l_related_products_grid">
                            <div class="agile_ecommerce_tab_left dresses_grid">
                                <div class="hs-wrapper hs-wrapper3">
                                    <?php $__currentLoopData = $offer_photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <?php if($item->productCode==$photo->productCode): ?>
                                            <img src="<?php echo e(asset('product-images/'.$photo->image)); ?>" alt=" "
                                                 class="img-responsive">

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                        <?php $__currentLoopData = $offer_photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <?php if($item->productCode==$photo->productCode): ?>
                                                <img src="<?php echo e(asset('product-images/'.$photo->image)); ?>" alt=" "
                                                     class="img-responsive">

                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

                                    <div class="w3_hs_bottom">
                                        <div class="flex_ecommerce">
                                            <a href="<?php echo e(url('product_details','productCode-'.$item->productCode)); ?>"><span
                                                        class="glyphicon glyphicon-eye-open" aria-hidden="true"></span></a>
                                        </div>
                                    </div>
                                </div>
                                <h5>
                                    <a href="<?php echo e(url('product_details','productCode-'.$item->productCode)); ?>"><?php echo e($item->name); ?></a>
                                </h5>
                                <div class="simpleCart_shelfItem">
                                    <?php if($item->offerPercentage==''): ?>
                                        <p class="flexisel_ecommerce_cart"><i class="item_price">BDT <?php echo e($item->price); ?>

                                                Tk</i></p>
                                    <?php else: ?>
                                        <p class="flexisel_ecommerce_cart"><i
                                                    class="item_price"><?php echo e($item->offerPrice); ?></i>
                                            <span><?php echo e($item->price); ?></span></p>

                                    <?php endif; ?>

                                    <p><a class="item_add"
                                          href="<?php echo e(url('product_details','productCode-'.$item->productCode)); ?>">View
                                            Details</a></p>
                                </div>
                            </div>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
            <script type="text/javascript">

            </script>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer_script'); ?>

    <script src="<?php echo e(asset('frontend/js/responsiveslides.min.js')); ?>"></script>

    <script>
        $(function () {
            // Slideshow 4
            $("#slider4").responsiveSlides({
                auto: true,
                pager: true,
                nav: true,
                speed: 700,
                namespace: "callbacks",
                before: function () {
                    $('.events').append("<li>before event fired.</li>");
                },
                after: function () {
                    $('.events').append("<li>after event fired.</li>");
                }
            });

        });


        $(window).load(function () {
            $("#flexiselDemo2").flexisel({
                visibleItems: 4,
                animationSpeed: 1000,
                autoPlay: true,
                autoPlaySpeed: 4000,
                pauseOnHover: true,
                enableResponsiveBreakpoints: true,
                responsiveBreakpoints: {
                    portrait: {
                        changePoint: 480,
                        visibleItems: 1
                    },
                    landscape: {
                        changePoint: 640,
                        visibleItems: 2
                    },
                    tablet: {
                        changePoint: 768,
                        visibleItems: 3
                    }
                }
            });

        });

        $(window).load(function () {
            $("#flexiselDemo3").flexisel({
                visibleItems: 4,
                animationSpeed: 1000,
                autoPlay: false,
                autoPlaySpeed: 4000,
                pauseOnHover: true,
                enableResponsiveBreakpoints: true,
                responsiveBreakpoints: {
                    portrait: {
                        changePoint: 480,
                        visibleItems: 1
                    },
                    landscape: {
                        changePoint: 640,
                        visibleItems: 2
                    },
                    tablet: {
                        changePoint: 768,
                        visibleItems: 3
                    }
                }
            });

        });

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>